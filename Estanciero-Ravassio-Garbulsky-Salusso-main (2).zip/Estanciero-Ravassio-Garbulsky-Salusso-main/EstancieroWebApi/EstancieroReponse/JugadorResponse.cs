﻿namespace EstancieroReponse
{
    public class JugadorResponse
    {
        public int DniJugador { get; set; }
        public string NombreJugador { get; set; }
        public int PartidasJugadas { get; set; }
        public int PartidasGanadas { get; set; }
        public int PartidasPerdidas { get; set; }
        public int PartidasPendientes { get; set; }

    }
}
