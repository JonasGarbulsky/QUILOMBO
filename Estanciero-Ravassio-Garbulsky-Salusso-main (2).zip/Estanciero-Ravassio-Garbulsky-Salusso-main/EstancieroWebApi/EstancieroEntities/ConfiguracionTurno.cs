﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstancieroEntities
{
    public class ConfiguracionTurnos
    {
        public int NumeroTurno { get; set; }
        public int DniJugador { get; set; }
    }
}
