﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstancieroEntities
{
    public class EstadisticaJugdor
    {
        public int PartidasJugadas { get; set; } = 0;
        public int PartidasGanadas { get; set; } = 0;
        public int PartidasPerdidas { get; set; } =0 ;
        public int PartidasPendientes { get; set; } = 0;
    }
}
